<?php
// Blogit extra - English default fields
$_lang['blogit.published_on'] = 'Published on';
$_lang['blogit.created_by'] = 'Created by';
$_lang['blogit.back_to_overview'] = 'Back to blog overview';
$_lang['blogit.readmore'] = 'Read more';
$_lang['blogit.tags_header'] = 'Tags';